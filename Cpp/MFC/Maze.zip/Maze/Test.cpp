#include "stdafx.h"
#include "Test.h"


Test::Test()
{
}


Test::~Test()
{
}
