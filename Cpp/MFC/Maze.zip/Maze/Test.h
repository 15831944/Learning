#pragma once
#include "atltypes.h"
class Test :
	public CRect
{
public:
	Test();
	~Test();
};

