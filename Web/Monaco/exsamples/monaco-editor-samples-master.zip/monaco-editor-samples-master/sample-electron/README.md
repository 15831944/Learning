To run this sample, you need to [download Electron](https://github.com/electron/electron/releases)

```
$/sample-electron> electron main.js
```